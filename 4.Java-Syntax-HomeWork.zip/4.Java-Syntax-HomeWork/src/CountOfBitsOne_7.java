import java.util.Scanner;


public class CountOfBitsOne_7 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		byte cnt = 0;
		int mask = 1;
		
		for (int i = 0; i < 16; i++) {			
			if (0< (n&(mask<<i))) {
				cnt ++;
			}
		}
		System.out.println(cnt);
	}

}
