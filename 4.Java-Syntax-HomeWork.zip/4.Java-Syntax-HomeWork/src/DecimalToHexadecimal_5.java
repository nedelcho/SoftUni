import java.util.Scanner;


public class DecimalToHexadecimal_5 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int dNum = scan.nextInt();
		
		System.out.printf("%H", dNum);
	}

}
