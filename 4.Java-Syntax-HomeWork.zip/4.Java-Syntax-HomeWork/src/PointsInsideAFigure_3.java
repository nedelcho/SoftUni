import java.util.Scanner;

public class PointsInsideAFigure_3 {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		while(true) {
			double x = scan.nextDouble();
			double y = scan.nextDouble();
			
			if (x<12.5 || x > 22.5 || y < 6 || y >13.5 || ((x>17.5 && x<20)&& (y>8.5))) {
				System.out.println("Outside");
			}
			else {
				System.out.println("Inside");
			}
		}

	}

}
