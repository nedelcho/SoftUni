import java.util.Scanner;


public class TheSmallestOf3Numbers_4 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		double a = scan.nextDouble();
		double b = scan.nextDouble();
		double c = scan.nextDouble();
		
		if (a>b) {
			a = b;
		}
		if (a>c) {
			a=c;
		}
		
		System.out.println(a);
	}

}
