import java.util.Scanner;

public class TriangleArea_2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int ax = scan.nextInt();
		int ay = scan.nextInt();
		int bx = scan.nextInt();
		int by = scan.nextInt();
		int cx = scan.nextInt();
		int cy = scan.nextInt();
		
		int result = ((ax*(by - cy)+bx*(cy-ay)+cx*(ay-by)))/2;
		if (result < 0) {
			result = ~result;
		}
		System.out.printf("%d\n", result);	
	}

}
